package modelTest;

import model.Loging;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class LogingTest { 
	
	private int idLogin = 1;
	private String username = "USER";
	private String password = "PASS";

		@Test
	    public void logingTest1() {
	    	Loging loging = new Loging();
	    	
	        Assert.assertEquals(0, loging.getIdLogin());
	        Assert.assertNull(loging.getUsername());
	        Assert.assertNull(loging.getPassword());
	    }
	    
		@Test
	    public void logingTest2() {
	    	Loging loging = new Loging(username, password);
	    	
	    	Assert.assertEquals(0, loging.getIdLogin());
	        Assert.assertEquals(username, loging.getUsername());
	        Assert.assertEquals(password, loging.getPassword());
	    }
	    
	    @Test
	    public void logingTest3() {
	    	Loging loging = new Loging(idLogin, username, password);
	    	
	        Assert.assertEquals(idLogin, loging.getIdLogin());
	        Assert.assertEquals(username, loging.getUsername());
	        Assert.assertEquals(password, loging.getPassword());
	    }


}

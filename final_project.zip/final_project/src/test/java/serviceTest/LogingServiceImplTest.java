package serviceTest;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import model.Loging;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.ContextConfiguration;

import dao.LogingDao;
import service.LogingServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration({"classpath*:servlet-context.xml"})
public class LogingServiceImplTest {
	
	// declare Mock Objects
	@InjectMocks  // request create Mock Objects for logingServiceImple (contain property of Mock Objects)
    private LogingServiceImpl logingServiceImpl;

    @Mock // be mocked Object
    private LogingDao logingDao;
    private List<Loging> list = new ArrayList<Loging>();
    
    private List<Loging> createLogingList(int length) {
    	List<Loging> listLoging = new ArrayList<Loging>();
        for (int i = 0; i < length; i++) {
            Loging question = createLoging(i, "USER_" + i, "Pass_" + i);
            listLoging.add(question);
        }
        return listLoging;
    }
    private Loging createLoging(int idLogin, String username, String password) {
    	Loging loging = new Loging(idLogin, username, password);
        return loging;
    }

    
/*-------------------------------------------------------------------------------------*/    
    @Before
    public void setUp() {//-simulate db
        MockitoAnnotations.initMocks(this);
        list = createLogingList(10);
        // test listLoging
        when(logingDao.listLoging()).thenAnswer(new Answer<List<Loging>>() {

            public List<Loging> answer(InvocationOnMock invocation)
                    throws Throwable {
                List<Loging> newList = new ArrayList<Loging>();
                for (int i = 0; i < list.size(); i++) {
                    newList.add(list.get(i));
                }
                return newList;
            }
        });
    }

    @Test
    public void getLogingTest() {
        List<Loging> listTest = logingServiceImpl.findAllLoging();
        Assert.assertTrue(listTest.size() == 10);
    }

}

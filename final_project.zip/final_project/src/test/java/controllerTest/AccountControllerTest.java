package controllerTest;

import static org.mockito.Mockito.mock;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
//import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
 
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;

import controller.AccountController;
import dao.AccountDao;
import model.Account;
import model.AccountType;
import model.State;
import service.AccountService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:servlet-context.xml" })
public class AccountControllerTest {

	// @Autowired
	// private WebApplicationContext wac;

	@InjectMocks
	private AccountController accountController;

	@Mock
	//@InjectMocks
	private AccountService accountService;

	@Mock
	private AccountDao accountDao;

	@Mock
	private Account account;
	
	@Valid
	private Account accountV = new Account();

//	@Mock
	private HttpServletRequest request;

	private MockMvc mockMvc;
	
	private ModelMap modelMap = new ModelMap();

	// private HttpServletRequest request;
	// =======================================================================
	private long accountNumber;

	private String accountNumberString;

	private String firstName;

	private String midName;

	private String lastName;

	private String phoneNumber1;

	private String phoneNumber2;

	private String email1;

	private String email2;

	private String address1;

	private String address2;

	private State state;

	private AccountType accountType;

	private long cardID;
	// ================================================

	private List<Account> listAccount = new ArrayList<Account>();

	//private static ModelMap modelMap;

	/*
	 * private long accountNumber = util.AutoNumberUtil.autoID();
	private String accountNumberString = String.valueOf(accountNumber);
	private String firstName = "first name";
	private String midName = "mid name";
	private String lastName = "last name";
	private String phoneNumber1 = "01223246232";
	private String phoneNumber2 = "01223246232";
	private String email1 = "email1@gmail.com";
	private String email2 = "email2@gmail.com";
	private String address1 = "adress 1";
	private String address2 = "adress 2";
	private State state = State.NEW;
	private AccountType accountType = AccountType.OTHER;
	private long cardID = util.AutoNumberUtil.autoCardID();
	 */
	// ===========================================================================================
//	 @Before
//	public void prepairUp() {
//
//		// //// // ===============SETUP FOR MOCK========================
//		MockitoAnnotations.initMocks(this);
//
//		
//	//	AccountController accountController = new AccountController();
//        ReflectionTestUtils.setField(accountController, "accountService", accountService);
//        mockMvc = MockMvcBuilders.standaloneSetup(accountController).build();
//		
//		accountNumber = util.AutoNumberUtil.autoID();
//		accountNumberString = String.valueOf(accountNumber);
//		firstName = "first name";
//		midName = "mid name";
//		lastName = "last name";
//		phoneNumber1 = "01223246232";
//		phoneNumber2 = "01223246232";
//		email1 = "email1@gmail.com";
//		email2 = "email2@gmail.com";
//		address1 = "adress 1";
//		address2 = "adress 2";
//		state = State.NEW;
//		accountType = AccountType.OTHER;
//		cardID = util.AutoNumberUtil.autoCardID();
//
//	}
	@Before
    public void prepairUp() {

        // //// // ===============SETUP FOR MOCK========================
        MockitoAnnotations.initMocks(this);
      //  AccountController accountController = new AccountController();
      //  ReflectionTestUtils.setField(accountController, "accountService", accountService);
        mockMvc = MockMvcBuilders.standaloneSetup(accountController).build();
    }


	@Test
	public void tesControllerListSearchtNull() throws Exception {
 

		final ModelMap modelMap = mock(ModelMap.class);// new ModelMap();
		final String result = accountController.listAccount(modelMap);
		 
		// ===GIA LAP METHOD
		when(accountService.findAllAccount()).thenReturn(listAccount);

		mockMvc.perform(get("/account/list")).andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.model().attribute("accounts", listAccount))
				.andExpect(MockMvcResultMatchers.view().name(result));

	}

	// ===========================================================================================
	@Test
	public void tesControllerSearchForm() throws Exception {
		mockMvc.perform(post("/search")).andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.model()
		.attribute("listAccounts", listAccount))
		.andExpect(MockMvcResultMatchers.view().name(accountController.searchForm(account, modelMap, request)));

		 
		
	}
	
	@Test
	public void testControllerSave()throws Exception {
		
		Account accountT = new Account();
		final ModelMap modelMap = mock(ModelMap.class);// new ModelMap();
	 
		mockMvc.perform(post("/add_new_account"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.model().attribute("accounts", accountT))
		.andExpect(MockMvcResultMatchers.view().name(accountController.addAccount(modelMap, request)));
		
		
		
	}
	
	

}

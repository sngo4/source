/**
 * js for updateAccount
 */

$(document).ready(function(){
	
	/*$(document).on("click", "#update-account", function(e) {
		  alert("Updated!");
	});*/
	
});

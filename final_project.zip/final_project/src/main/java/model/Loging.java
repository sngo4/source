/*---------------------------------------------Sang----------------------------------------------------------------*/
package model;

@SuppressWarnings("serial")
public class Loging implements java.io.Serializable {
	private int idLogin;
	private String username;
	private String password;

	public Loging() {

	}

	public Loging(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public Loging(int idLogin, String username, String password) {
		this.idLogin = idLogin;
		this.username = username;
		this.password = password;

	}

	public int getIdLogin() {
		return idLogin;
	}

	public void setIdLogin(int idLogin) {
		this.idLogin = idLogin;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
